import React from 'react'
import './FooterContent'

function FooterContent() {
  return (
    <div id = "footerconte">
        <h3>FooterContent</h3>
    </div>
  )
}

export default FooterContent